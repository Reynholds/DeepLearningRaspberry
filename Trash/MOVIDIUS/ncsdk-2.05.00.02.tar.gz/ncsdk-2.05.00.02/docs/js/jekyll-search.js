!function e(t, n, r) {
    function s(o, u) {
        if (!n[o]) {
            if (!t[o]) {
                var a = "function" == typeof require && require;
                if (!u && a) return a(o, !0);
                if (i) return i(o, !0);
                throw new Error("Cannot find module '" + o + "'")
            }
            var f = n[o] = {exports: {}};
            t[o][0].call(f.exports, function (e) {
                var n = t[o][1][e];
                return s(n ? n : e)
            }, f, f.exports, e, t, n, r)
        }
        return n[o].exports
    }

    for (var i = "function" == typeof require && require, o = 0; o < r.length; o++) s(r[o]);
    return s
}({
    1: [function (require, module) {
        module.exports = function () {
            function receivedResponse(xhr) {
                return 200 == xhr.status && 4 == xhr.readyState
            }

            function handleResponse(xhr, callback) {
                xhr.onreadystatechange = function () {
                    if (receivedResponse(xhr)) try {
                        callback(null, JSON.parse(xhr.responseText))
                    } catch (err) {
                        callback(err, null)
                    }
                }
            }

            var self = this;
            self.load = function (location, callback) {
                var xhr = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP");
                xhr.open("GET", location, !0), handleResponse(xhr, callback), xhr.send()
            }
        }
    }, {}], 2: [function (require, module) {
        function FuzzySearchStrategy() {
            function createFuzzyRegExpFromString(string) {
                return new RegExp(string.split("").join(".*?"), "gi")
            }

            var self = this;
            self.matches = function (string, crit) {
                return "string" != typeof string ? !1 : (string = string.trim(), !!string.match(createFuzzyRegExpFromString(crit)))
            }
        }

        module.exports = new FuzzySearchStrategy
    }, {}], 3: [function (require, module) {
        function LiteralSearchStrategy() {
            function doMatch(string, crit) {
                return string.toLowerCase().indexOf(crit.toLowerCase()) >= 0
            }

            var self = this;
            self.matches = function (string, crit) {
                return "string" != typeof string ? !1 : (string = string.trim(), doMatch(string, crit))
            }
        }

        module.exports = new LiteralSearchStrategy
    }, {}], 4: [function (require, module) {
        module.exports = function () {
            function findMatches(store, crit, strategy) {
                for (var data = store.get(), i = 0; i < data.length && matches.length < limit; i++) findMatchesInObject(data[i], crit, strategy);
                return matches
            }

            function findMatchesInObject(obj, crit, strategy) {
                for (var key in obj) if (key != "display" && key != "url" && strategy.matches(obj[key], crit)) {
                    matches.push(obj);
                    break
                }
            }

            function getSearchStrategy() {
                return fuzzy ? fuzzySearchStrategy : literalSearchStrategy
            }

            var self = this, matches = [], fuzzy = !1, limit = 10,
                fuzzySearchStrategy = require("./SearchStrategies/fuzzy"),
                literalSearchStrategy = require("./SearchStrategies/literal");
            self.setFuzzy = function (_fuzzy) {
                fuzzy = !!_fuzzy
            }, self.setLimit = function (_limit) {
                limit = parseInt(_limit, 10) || limit
            }, self.search = function (data, crit) {
                return crit ? (matches.length = 0, findMatches(data, crit, getSearchStrategy())) : []
            }
        }
    }, {"./SearchStrategies/fuzzy": 2, "./SearchStrategies/literal": 3}], 5: [function (require, module) {
        module.exports = function (_store) {
            function isObject(obj) {
                return !!obj && "[object Object]" == Object.prototype.toString.call(obj)
            }

            function isArray(obj) {
                return !!obj && "[object Array]" == Object.prototype.toString.call(obj)
            }

            function addObject(data) {
                return store.push(data), data
            }

            function addArray(data) {
                for (var added = [], i = 0; i < data.length; i++) isObject(data[i]) && added.push(addObject(data[i]));
                return added
            }

            var self = this, store = [];
            isArray(_store) && addArray(_store), self.clear = function () {
                return store.length = 0, store
            }, self.get = function () {
                return store
            }, self.put = function (data) {
                return isObject(data) ? addObject(data) : isArray(data) ? addArray(data) : void 0
            }
        }
    }, {}], 6: [function (require, module) {
        module.exports = function () {
            var self = this, templatePattern = /\{(.*?)\}/g;
            self.setTemplatePattern = function (newTemplatePattern) {
                templatePattern = newTemplatePattern
            }, self.render = function (t, data) {
                return t.replace(templatePattern, function (match, prop) {
                    return data[prop] || match
                })
            }
        }
    }, {}], 7: [function (require) {
        !function (window) {
            "use strict";

            function SimpleJekyllSearch() {
                function initWithJSON() {
                    store.put(opt.dataSource), registerInput()
                }

                function initWithURL(url) {
                    jsonLoader.load(url, function (err, json) {
                        err ? throwError("failed to get JSON (" + url + ")") : (store.put(json), registerInput())
                    })
                }

                function throwError(message) {
                    throw new Error("SimpleJekyllSearch --- " + message)
                }

                function validateOptions(_opt) {
                    for (var i = 0; i < requiredOptions.length; i++) {
                        var req = requiredOptions[i];
                        _opt[req] || throwError("You must specify a " + req)
                    }
                }

                function assignOptions(_opt) {
                    for (var option in opt) opt[option] = _opt[option] || opt[option]
                }

                function isJSON(json) {
                    try {
                        return json instanceof Object && JSON.parse(JSON.stringify(json))
                    } catch (e) {
                        return !1
                    }
                }

                function emptyResultsContainer() {
                    opt.resultsContainer.innerHTML = ""
                }

                function appendToResultsContainer(text) {
                    opt.resultsContainer.innerHTML += text
                }

                function registerInput() {
                    opt.searchInput.addEventListener("keyup", function (e) {
                        return 0 == e.target.value.length ? void emptyResultsContainer() : void render(searcher.search(store, e.target.value))
                    })
                }

                function render(results) {
                    if (emptyResultsContainer(), 0 == results.length) return appendToResultsContainer(opt.noResultsText);
                    for (var i = 0; i < results.length; i++) appendToResultsContainer(templater.render(opt.searchResultTemplate, results[i]))
                }

                var self = this, requiredOptions = ["searchInput", "resultsContainer", "dataSource"], opt = {
                    searchInput: null,
                    resultsContainer: null,
                    dataSource: [],
                    searchResultTemplate: '<li><a href="{url}" title="{desc}">{title}</a></li>',
                    noResultsText: "No results found",
                    limit: 10,
                    fuzzy: !1
                };
                self.init = function (_opt) {
                    validateOptions(_opt), assignOptions(_opt), isJSON(opt.dataSource) ? initWithJSON(opt.dataSource) : initWithURL(opt.dataSource)
                }
            }

            var Searcher = require("./Searcher"), Templater = require("./Templater"), Store = require("./Store"),
                JSONLoader = require("./JSONLoader"), searcher = new Searcher, templater = new Templater,
                store = new Store, jsonLoader = new JSONLoader;
            window.SimpleJekyllSearch = new SimpleJekyllSearch
        }(window, document)
    }, {"./JSONLoader": 1, "./Searcher": 4, "./Store": 5, "./Templater": 6}]
}, {}, [7]);
