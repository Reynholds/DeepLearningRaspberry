-------
Documentation for the NCSDK is best viewed by pointing your browser here: https://movidius.github.io/ncsdk/
-------
-------
