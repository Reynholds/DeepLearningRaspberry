#! /bin/bash

g++ run.cpp fp16.c -o run_cpp -lmvnc



