# Examples showing TensorFlow usage
